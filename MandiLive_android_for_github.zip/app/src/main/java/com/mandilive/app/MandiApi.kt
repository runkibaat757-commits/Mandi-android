package com.mandilive.app

import retrofit2.http.GET
import retrofit2.http.Query

data class ApiResponse(
    val success: Boolean,
    val count: Int = 0,
    val records: List<MandiRecord> = emptyList(),
    val message: String? = null,
    val source: String? = null,
    val cached: Boolean? = null,
    val retrieved_at: String? = null
)

data class MandiRecord(
    val state: String? = null,
    val district: String? = null,
    val market: String? = null,
    val commodity: String? = null,
    val variety: String? = null,
    val grade: String? = null,
    val arrival_date: String? = null,
    val min_price: String? = null,
    val max_price: String? = null,
    val modal_price: String? = null
)

interface MandiApi {
    @GET("mandi.php")
    suspend fun getMandi(@Query("state") state:String?=null,@Query("district") district:String?=null,@Query("market") market:String?=null,@Query("commodity") commodity:String?=null,@Query("limit") limit:Int=100,@Query("refresh") refresh:Int=0):ApiResponse
}
