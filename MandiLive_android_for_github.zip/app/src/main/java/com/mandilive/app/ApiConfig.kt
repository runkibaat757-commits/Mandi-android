package com.mandilive.app

object ApiConfig {
    // Put your PHP backend API URL here. Example: https://example.com/api/
    const val BASE_URL = "https://mandi.freedev.app/api/"
}
