package com.mandilive.app

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class MainActivity : AppCompatActivity() {
    private lateinit var adapter: MandiAdapter
    private lateinit var stateView: AutoCompleteTextView
    private lateinit var districtView: AutoCompleteTextView
    private lateinit var marketView: AutoCompleteTextView
    private lateinit var commodityView: AutoCompleteTextView
    private lateinit var searchBtn: Button
    private lateinit var progress: ProgressBar
    private lateinit var statusView: TextView

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val api by lazy {
        Retrofit.Builder()
            .baseUrl(ApiConfig.BASE_URL)
            .client(OkHttpClient.Builder().build())
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(MandiApi::class.java)
    }

    private fun txt(v: AutoCompleteTextView): String? = v.text.toString().trim().ifBlank { null }

    private fun loadFilter(
        type: String,
        target: AutoCompleteTextView,
        st: String? = null,
        di: String? = null,
        show: Boolean = false
    ) {
        scope.launch {
            try {
                val r = withContext(Dispatchers.IO) { api.getFilters(type, st, di) }
                if (r.success) {
                    target.setAdapter(
                        ArrayAdapter(this@MainActivity, android.R.layout.simple_dropdown_item_1line, r.items)
                    )
                    if (show && target.hasFocus() && r.items.isNotEmpty()) target.showDropDown()
                }
            } catch (e: Exception) {
                // list load failed; user can still type manually
            }
        }
    }

    private fun load(refresh: Int = 0) {
        val st = txt(stateView)
        val di = txt(districtView)
        val mk = txt(marketView)
        val cm = txt(commodityView)
        progress.visibility = View.VISIBLE
        searchBtn.isEnabled = false
        scope.launch {
            try {
                val r = withContext(Dispatchers.IO) { api.getMandi(st, di, mk, cm, 100, refresh) }
                if (r.success) {
                    adapter.submit(r.records)
                    val cachedTag = if (r.cached == true) " • Cached" else ""
                    statusView.text = (r.source ?: "MandiLive") + " • " + r.count + " रिकॉर्ड" + cachedTag
                    if (r.records.isEmpty()) {
                        Toast.makeText(this@MainActivity, "कोई रिकॉर्ड नहीं मिला", Toast.LENGTH_SHORT).show()
                    }
                    loadFilter("states", stateView)
                } else {
                    Toast.makeText(this@MainActivity, r.message ?: "Error", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this@MainActivity, "Server/API error: " + e.message, Toast.LENGTH_LONG).show()
            } finally {
                progress.visibility = View.GONE
                searchBtn.isEnabled = true
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val list = findViewById<RecyclerView>(R.id.list)
        progress = findViewById(R.id.progress)
        statusView = findViewById(R.id.status)
        stateView = findViewById(R.id.state)
        districtView = findViewById(R.id.district)
        marketView = findViewById(R.id.market)
        commodityView = findViewById(R.id.commodity)
        searchBtn = findViewById(R.id.search)

        adapter = MandiAdapter()
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = adapter

        for (v in listOf(stateView, districtView, marketView, commodityView)) {
            v.threshold = 0
            v.setOnClickListener { v.showDropDown() }
        }

        stateView.setOnItemClickListener { _, _, _, _ ->
            districtView.setText("")
            marketView.setText("")
            loadFilter("districts", districtView, txt(stateView))
            loadFilter("commodities", commodityView, txt(stateView))
        }
        districtView.setOnItemClickListener { _, _, _, _ ->
            marketView.setText("")
            loadFilter("markets", marketView, null, txt(districtView))
        }
        districtView.setOnFocusChangeListener { _, hasFocus ->
            if (hasFocus) loadFilter("districts", districtView, txt(stateView), null, true)
        }
        marketView.setOnFocusChangeListener { _, hasFocus ->
            if (hasFocus) loadFilter("markets", marketView, null, txt(districtView), true)
        }

        loadFilter("states", stateView)
        loadFilter("commodities", commodityView, txt(stateView))

        searchBtn.setOnClickListener { load(1) }
        load(0)
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}

class MandiAdapter : RecyclerView.Adapter<MandiAdapter.VH>() {
    private val data = mutableListOf<MandiRecord>()

    fun submit(items: List<MandiRecord>) {
        data.clear()
        data.addAll(items)
        notifyDataSetChanged()
    }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val commodity: TextView = v.findViewById(R.id.commodity)
        val market: TextView = v.findViewById(R.id.market)
        val prices: TextView = v.findViewById(R.id.prices)
        val date: TextView = v.findViewById(R.id.date)
    }

    override fun onCreateViewHolder(p: ViewGroup, t: Int): VH =
        VH(LayoutInflater.from(p.context).inflate(R.layout.item_mandi, p, false))

    override fun onBindViewHolder(h: VH, p: Int) {
        val x = data[p]
        h.commodity.text = x.commodity ?: "-"
        h.market.text = (x.market ?: "-") + " • " + (x.district ?: "-") + " • " + (x.variety ?: "-")
        h.prices.text = "Min ₹" + (x.min_price ?: "-") + "   Max ₹" + (x.max_price ?: "-") + "   Modal ₹" + (x.modal_price ?: "-")
        h.date.text = "भाव तारीख: " + (x.arrival_date ?: "-")
    }

    override fun getItemCount() = data.size
}
