package com.mandilive.app

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.*
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class MainActivity : AppCompatActivity() {
    private lateinit var adapter: MandiAdapter
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val api by lazy { Retrofit.Builder().baseUrl(ApiConfig.BASE_URL).client(OkHttpClient.Builder().build()).addConverterFactory(GsonConverterFactory.create()).build().create(MandiApi::class.java) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState); setContentView(R.layout.activity_main)
        val list=findViewById<RecyclerView>(R.id.list); val progress=findViewById<ProgressBar>(R.id.progress)
        val state=findViewById<EditText>(R.id.state); val district=findViewById<EditText>(R.id.district); val market=findViewById<EditText>(R.id.market); val commodity=findViewById<EditText>(R.id.commodity); val search=findViewById<Button>(R.id.search)
        adapter=MandiAdapter(); list.layoutManager=LinearLayoutManager(this); list.adapter=adapter
        fun load(refresh:Int=0){ progress.visibility=View.VISIBLE; search.isEnabled=false; scope.launch { try { val r=withContext(Dispatchers.IO){api.getMandi(state.text.toString().trim().ifBlank{null},district.text.toString().trim().ifBlank{null},market.text.toString().trim().ifBlank{null},commodity.text.toString().trim().ifBlank{null},100,refresh)}; if(r.success){adapter.submit(r.records); findViewById<TextView>(R.id.status).text="${r.source ?: "MandiLive"} • ${r.count} रिकॉर्ड${if(r.cached==true) " • Cached" else ""}"; if(r.records.isEmpty())Toast.makeText(this@MainActivity,"कोई रिकॉर्ड नहीं मिला",Toast.LENGTH_SHORT).show()}else Toast.makeText(this@MainActivity,r.message? :"Error",Toast.LENGTH_LONG).show()}catch(e:Exception){Toast.makeText(this@MainActivity,"Server/API error: ${e.message}",Toast.LENGTH_LONG).show()}finally{progress.visibility=View.GONE;search.isEnabled=true} } }
        search.setOnClickListener{load(1)}; load(0)
    }
    override fun onDestroy(){scope.cancel();super.onDestroy()}
}

class MandiAdapter:RecyclerView.Adapter<MandiAdapter.VH>(){
 private val data=mutableListOf<MandiRecord>(); fun submit(items:List<MandiRecord>){data.clear();data.addAll(items);notifyDataSetChanged()}
 class VH(v:View):RecyclerView.ViewHolder(v){val commodity:TextView=v.findViewById(R.id.commodity);val market:TextView=v.findViewById(R.id.market);val prices:TextView=v.findViewById(R.id.prices);val date:TextView=v.findViewById(R.id.date)}
 override fun onCreateViewHolder(p:ViewGroup,t:Int)=VH(LayoutInflater.from(p.context).inflate(R.layout.item_mandi,p,false))
 override fun onBindViewHolder(h:VH,p:Int){val x=data[p];h.commodity.text=x.commodity?:"-";h.market.text="${x.market?:"-"} • ${x.district?:"-"} • ${x.variety?:"-"}";h.prices.text="Min ₹${x.min_price?:"-"}   Max ₹${x.max_price?:"-"}   Modal ₹${x.modal_price?:"-"}";h.date.text="भाव तारीख: ${x.arrival_date?:"-"}"}
 override fun getItemCount()=data.size
}
